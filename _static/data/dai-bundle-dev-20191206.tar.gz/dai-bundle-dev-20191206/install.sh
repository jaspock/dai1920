#!/bin/bash

# Instala Node.js, SQLite3, el SDK de Google Cloud Platform o el CLI de Heroku.
# No se necesita conexión a internet excepto para el CLI de Heroku.

# Poner la variable a true para los programas a instalar: 

node=true
sqlite=false
gcloud=false
heroku=false

if [ "$node" = true ] ; then
  echo "Instalando Node.js..."
  tar xzf node-v12.13.1-linux-x64.tar.gz -C $HOME
  echo 'export PATH=$HOME/node-v12.13.1-linux-x64/bin:$PATH' >> $HOME/.bashrc
fi

if [ "$sqlite" = true ] ; then
  echo "Instalando SQLite3..."
  unzip -q -o sqlite-tools-linux-x86-3300100.zip -d $HOME
  echo 'export PATH=$HOME/sqlite-tools-linux-x86-3300100:$PATH' >> $HOME/.bashrc
  echo "Podría ser necesario para SQLite3 ejecutar: sudo apt-get install libc6-i386 lib32z1" 
fi

if [ "$gcloud" = true ] ; then
  echo "Instalando Google Cloud Platform SDK..."
  tar xzf google-cloud-sdk-272.0.0-linux-x86_64.tar.gz -C $HOME
  echo 'export PATH=$HOME/google-cloud-sdk/bin:$PATH' >> $HOME/.bashrc
  echo "Se recomienda ejecutar en un nuevo terminal: gcloud components update"
fi

if [ "$heroku" = true ] ; then
  echo "Descargando e instalando Heroku CLI..."
  curl -O -s https://cli-assets.heroku.com/heroku-linux-x64.tar.gz
  tar xzf heroku-linux-x64.tar.gz -C $HOME
  echo 'export PATH=$HOME/heroku/bin:$PATH' >> $HOME/.bashrc
fi

RED='\033[0;31m'
NC='\033[0m'

echo
echo -e "${RED}Atención:${NC} abre un nuevo terminal para poder ejecutar los programas instalados."
echo

